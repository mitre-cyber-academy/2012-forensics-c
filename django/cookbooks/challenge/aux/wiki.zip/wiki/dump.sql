DROP TABLE IF EXISTS auth_permission;
CREATE TABLE IF NOT EXISTS `auth_permission` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `name` varchar(50) NOT NULL,
    `content_type_id` integer NOT NULL,
    `codename` varchar(100) NOT NULL,
    UNIQUE (`content_type_id`, `codename`)
);
INSERT INTO auth_permission VALUES(1,'Can add permission',1,'add_permission');
INSERT INTO auth_permission VALUES(2,'Can change permission',1,'change_permission');
INSERT INTO auth_permission VALUES(3,'Can delete permission',1,'delete_permission');
INSERT INTO auth_permission VALUES(4,'Can add group',2,'add_group');
INSERT INTO auth_permission VALUES(5,'Can change group',2,'change_group');
INSERT INTO auth_permission VALUES(6,'Can delete group',2,'delete_group');
INSERT INTO auth_permission VALUES(7,'Can add user',3,'add_user');
INSERT INTO auth_permission VALUES(8,'Can change user',3,'change_user');
INSERT INTO auth_permission VALUES(9,'Can delete user',3,'delete_user');
INSERT INTO auth_permission VALUES(10,'Can add message',4,'add_message');
INSERT INTO auth_permission VALUES(11,'Can change message',4,'change_message');
INSERT INTO auth_permission VALUES(12,'Can delete message',4,'delete_message');
INSERT INTO auth_permission VALUES(13,'Can add content type',5,'add_contenttype');
INSERT INTO auth_permission VALUES(14,'Can change content type',5,'change_contenttype');
INSERT INTO auth_permission VALUES(15,'Can delete content type',5,'delete_contenttype');
INSERT INTO auth_permission VALUES(16,'Can add session',6,'add_session');
INSERT INTO auth_permission VALUES(17,'Can change session',6,'change_session');
INSERT INTO auth_permission VALUES(18,'Can delete session',6,'delete_session');
INSERT INTO auth_permission VALUES(19,'Can add site',7,'add_site');
INSERT INTO auth_permission VALUES(20,'Can change site',7,'change_site');
INSERT INTO auth_permission VALUES(21,'Can delete site',7,'delete_site');
INSERT INTO auth_permission VALUES(22,'Can add Article',8,'add_article');
INSERT INTO auth_permission VALUES(23,'Can change Article',8,'change_article');
INSERT INTO auth_permission VALUES(24,'Can delete Article',8,'delete_article');
INSERT INTO auth_permission VALUES(25,'Can add article attachment',9,'add_articleattachment');
INSERT INTO auth_permission VALUES(26,'Can change article attachment',9,'change_articleattachment');
INSERT INTO auth_permission VALUES(27,'Can delete article attachment',9,'delete_articleattachment');
INSERT INTO auth_permission VALUES(28,'Can add article revision',10,'add_revision');
INSERT INTO auth_permission VALUES(29,'Can change article revision',10,'change_revision');
INSERT INTO auth_permission VALUES(30,'Can delete article revision',10,'delete_revision');
INSERT INTO auth_permission VALUES(31,'Can add Article permission',11,'add_permission');
INSERT INTO auth_permission VALUES(32,'Can change Article permission',11,'change_permission');
INSERT INTO auth_permission VALUES(33,'Can delete Article permission',11,'delete_permission');
DROP TABLE IF EXISTS auth_group;
CREATE TABLE IF NOT EXISTS `auth_group` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `name` varchar(80) NOT NULL UNIQUE
);
DROP TABLE IF EXISTS auth_user;
CREATE TABLE IF NOT EXISTS `auth_user` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `username` varchar(30) NOT NULL UNIQUE,
    `first_name` varchar(30) NOT NULL,
    `last_name` varchar(30) NOT NULL,
    `email` varchar(75) NOT NULL,
    `password` varchar(128) NOT NULL,
    `is_staff` bool NOT NULL,
    `is_active` bool NOT NULL,
    `is_superuser` bool NOT NULL,
    `last_login` datetime NOT NULL,
    `date_joined` datetime NOT NULL
);
INSERT INTO auth_user VALUES(1,'admin','','','admin@skip.com','sha1$0d868$242e26e9704fe69f4294fa0e691b15f19c35bce5',1,1,1,'2012-06-26 09:56:23.837555','2012-06-26 09:56:23.837555');
DROP TABLE IF EXISTS auth_message;
CREATE TABLE IF NOT EXISTS `auth_message` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `user_id` integer NOT NULL REFERENCES `auth_user` (`id`),
    `message` text NOT NULL
);
DROP TABLE IF EXISTS django_content_type;
CREATE TABLE IF NOT EXISTS `django_content_type` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `name` varchar(100) NOT NULL,
    `app_label` varchar(100) NOT NULL,
    `model` varchar(100) NOT NULL,
    UNIQUE (`app_label`, `model`)
);
INSERT INTO django_content_type VALUES(1,'permission','auth','permission');
INSERT INTO django_content_type VALUES(2,'group','auth','group');
INSERT INTO django_content_type VALUES(3,'user','auth','user');
INSERT INTO django_content_type VALUES(4,'message','auth','message');
INSERT INTO django_content_type VALUES(5,'content type','contenttypes','contenttype');
INSERT INTO django_content_type VALUES(6,'session','sessions','session');
INSERT INTO django_content_type VALUES(7,'site','sites','site');
INSERT INTO django_content_type VALUES(8,'Article','simplewiki','article');
INSERT INTO django_content_type VALUES(9,'article attachment','simplewiki','articleattachment');
INSERT INTO django_content_type VALUES(10,'article revision','simplewiki','revision');
INSERT INTO django_content_type VALUES(11,'Article permission','simplewiki','permission');
DROP TABLE IF EXISTS django_session;
CREATE TABLE IF NOT EXISTS `django_session` (
    `session_key` varchar(40) NOT NULL PRIMARY KEY,
    `session_data` text NOT NULL,
    `expire_date` datetime NOT NULL
);
DROP TABLE IF EXISTS django_site;
CREATE TABLE IF NOT EXISTS `django_site` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `domain` varchar(100) NOT NULL,
    `name` varchar(50) NOT NULL
);
INSERT INTO django_site VALUES(1,'example.com','example.com');
DROP TABLE IF EXISTS simplewiki_article;
CREATE TABLE IF NOT EXISTS `simplewiki_article` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `title` varchar(512) NOT NULL,
    `slug` varchar(100) NOT NULL,
    `created_by_id` integer REFERENCES `auth_user` (`id`),
    `created_on` datetime NOT NULL,
    `modified_on` datetime NOT NULL,
    `parent_id` integer,
    `locked` bool NOT NULL,
    `permissions_id` integer,
    `current_revision_id` integer UNIQUE,
    UNIQUE (`slug`, `parent_id`)
);
INSERT INTO simplewiki_article VALUES(1,'Rootsies','',NULL,'2012-06-26 09:57:03.983291','2012-06-26 09:57:03.983342',NULL,0,NULL,1);
INSERT INTO simplewiki_article VALUES(2,'Stuff','Stuff',NULL,'2012-06-26 09:57:31.532539','2012-06-26 09:57:31.532559',1,0,NULL,2);
INSERT INTO simplewiki_article VALUES(4,'Testing','Testing',NULL,'2012-06-26 10:37:40.588845','2012-06-26 10:37:40.588875',2,0,NULL,4);
DROP TABLE IF EXISTS simplewiki_articleattachment;
CREATE TABLE IF NOT EXISTS `simplewiki_articleattachment` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `article_id` integer NOT NULL REFERENCES `simplewiki_article` (`id`),
    `file` varchar(255) NOT NULL,
    `uploaded_by_id` integer REFERENCES `auth_user` (`id`),
    `uploaded_on` datetime NOT NULL
);
DROP TABLE IF EXISTS simplewiki_revision;
CREATE TABLE IF NOT EXISTS `simplewiki_revision` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `article_id` integer NOT NULL REFERENCES `simplewiki_article` (`id`),
    `revision_text` varchar(255),
    `revision_user_id` integer REFERENCES `auth_user` (`id`),
    `revision_date` datetime NOT NULL,
    `contents` text NOT NULL,
    `contents_parsed` text,
    `counter` integer NOT NULL,
    `previous_revision_id` integer
);
INSERT INTO simplewiki_revision VALUES(1,1,NULL,NULL,'2012-06-26 09:57:04.029770','Headline
===

','<h1 id="headline">Headline</h1>',1,NULL);
INSERT INTO simplewiki_revision VALUES(2,2,NULL,NULL,'2012-06-26 09:57:31.627423','Headline
===

This is an article

','<h1 id="headline">Headline</h1>
<p>This is an article</p>',1,NULL);
INSERT INTO simplewiki_revision VALUES(4,4,'','','2012-06-26 10:37:40.629553','Headline
===
Woot','<h1 id="headline">Headline</h1>
<p>Woot</p>',1,'');
DROP TABLE IF EXISTS simplewiki_permission;
CREATE TABLE IF NOT EXISTS `simplewiki_permission` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `permission_name` varchar(255) NOT NULL
);
DROP TABLE IF EXISTS auth_group_permissions;
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `group_id` integer NOT NULL REFERENCES `auth_group` (`id`),
    `permission_id` integer NOT NULL REFERENCES `auth_permission` (`id`),
    UNIQUE (`group_id`, `permission_id`)
);
DROP TABLE IF EXISTS auth_user_groups;
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `user_id` integer NOT NULL REFERENCES `auth_user` (`id`),
    `group_id` integer NOT NULL REFERENCES `auth_group` (`id`),
    UNIQUE (`user_id`, `group_id`)
);
DROP TABLE IF EXISTS auth_user_user_permissions;
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `user_id` integer NOT NULL REFERENCES `auth_user` (`id`),
    `permission_id` integer NOT NULL REFERENCES `auth_permission` (`id`),
    UNIQUE (`user_id`, `permission_id`)
);
DROP TABLE IF EXISTS simplewiki_article_related;
CREATE TABLE IF NOT EXISTS `simplewiki_article_related` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `from_article_id` integer NOT NULL REFERENCES `simplewiki_article` (`id`),
    `to_article_id` integer NOT NULL REFERENCES `simplewiki_article` (`id`),
    UNIQUE (`from_article_id`, `to_article_id`)
);
DROP TABLE IF EXISTS simplewiki_permission_can_write;
CREATE TABLE IF NOT EXISTS `simplewiki_permission_can_write` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `permission_id` integer NOT NULL REFERENCES `simplewiki_permission` (`id`),
    `user_id` integer NOT NULL REFERENCES `auth_user` (`id`),
    UNIQUE (`permission_id`, `user_id`)
);
DROP TABLE IF EXISTS simplewiki_permission_can_read;
CREATE TABLE IF NOT EXISTS `simplewiki_permission_can_read` (
    `id` integer NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `permission_id` integer NOT NULL REFERENCES `simplewiki_permission` (`id`),
    `user_id` integer NOT NULL REFERENCES `auth_user` (`id`),
    UNIQUE (`permission_id`, `user_id`)
);
CREATE INDEX `auth_permission_content_type_id` ON `auth_permission` (`content_type_id`);
CREATE INDEX `auth_message_user_id` ON `auth_message` (`user_id`);
CREATE INDEX `simplewiki_article_slug` ON `simplewiki_article` (`slug`);
CREATE INDEX `simplewiki_article_created_by_id` ON `simplewiki_article` (`created_by_id`);
CREATE INDEX `simplewiki_article_parent_id` ON `simplewiki_article` (`parent_id`);
CREATE INDEX `simplewiki_article_permissions_id` ON `simplewiki_article` (`permissions_id`);
CREATE INDEX `simplewiki_articleattachment_article_id` ON `simplewiki_articleattachment` (`article_id`);
CREATE INDEX `simplewiki_articleattachment_uploaded_by_id` ON `simplewiki_articleattachment` (`uploaded_by_id`);
CREATE INDEX `simplewiki_revision_article_id` ON `simplewiki_revision` (`article_id`);
CREATE INDEX `simplewiki_revision_revision_user_id` ON `simplewiki_revision` (`revision_user_id`);
CREATE INDEX `simplewiki_revision_previous_revision_id` ON `simplewiki_revision` (`previous_revision_id`);
